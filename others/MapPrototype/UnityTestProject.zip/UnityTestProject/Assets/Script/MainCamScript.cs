﻿using UnityEngine;
using System.Collections;
using System;

public class MainCamScript : MonoBehaviour {

    Vector3 sollPos;
    float scrollSpeed;

	// Use this for initialization
	void Start () {
        sollPos = this.transform.position;
        scrollSpeed = 50f;
	}
	
	// Update is called once per frame
	void Update () {
        if (this.transform.position != sollPos)
        {
            float totalMovementSpeed = Time.deltaTime * scrollSpeed;
            this.transform.position = Vector3.MoveTowards(this.transform.position, sollPos, totalMovementSpeed);
        }
    }

    void FixedUpdate()
    {
    }

    /// <summary>
    /// changes the new destination of the cam
    /// </summary>
    /// <param name="newDestination"></param>
    public void changeDestination(Vector3 newDestination)
    {
        this.sollPos = newDestination;
    }

}
