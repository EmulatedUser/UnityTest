﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerBehaviour : MonoBehaviour {

    public float maxSpeed = 1f;
    public float maxHealth = 5f;
    public float startHealth = 3f;
    public float health = 0f;

    //Gui
    public Image healthGui;
    public Image manaGui;

    [HideInInspector] // versteckt public in Unity...
    public bool lookingRight = false;
    //private Animator anim;

    /// <summary>
    /// Use this for initialization
    /// </summary>
    void Start() {
        health = startHealth;
        UpdatePlayerGUI();
    }

    /// <summary>
    /// Update is called once per frame
    /// </summary>
    void Update() {
    }

    /// <summary>
    /// ...
    /// </summary>
    void FixedUpdate()
    {
        float hor = Input.GetAxis("Horizontal");
        float ver = Input.GetAxis("Vertical");
        //anim.SetFloat("Speed", Mathf.Abs(hor));

        Vector3 newPosition = this.transform.position;
        newPosition.x += (hor * 0.1f);
        newPosition.y += (ver * 0.1f);
        this.transform.position = newPosition;

        if ((hor > 0 && !lookingRight) || (hor < 0 && lookingRight))
        {
            Flip();
        }
    }

    /// <summary>
    /// Flips the Character Sprite
    /// </summary>
    public void Flip()
    {
        lookingRight = !lookingRight;
        if (lookingRight)
        {
            Vector3 myScale = transform.localScale;
            myScale.x = -1;
            transform.localScale = myScale;
        }
        else
        {
            Vector3 myScale = transform.localScale;
            myScale.x = 1;
            transform.localScale = myScale;
        }
    }

    public void UpdatePlayerGUI()
    {
        healthGui.fillAmount = health / maxHealth;
    }

    public void ApplyDamage(float damageAmount)
    {
        if(damageAmount < health)
        {
            health = health - damageAmount;
        }
        else
        {
            health = 0;
        }
        UpdatePlayerGUI();
    }

}
