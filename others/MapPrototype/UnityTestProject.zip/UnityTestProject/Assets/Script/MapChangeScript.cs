﻿using UnityEngine;
using System.Collections;
using System;

public class MapChangeScript : MonoBehaviour {

    public Transform camTarget;

    // Use this for initialization
    void Start () {

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            //Camera.main.transform.position = new Vector3(camTarget.position.x, camTarget.position.y, Camera.main.transform.position.z);
            Vector3 newCamPos = new Vector3(camTarget.position.x, camTarget.position.y, Camera.main.transform.position.z);
            Camera.main.SendMessage("changeDestination", newCamPos);
        }
    }

    // Update is called once per frame
    void Update() {
    }

}
